import ProductList from './ProductList';
import './ProductList.css';

export default ProductList;
